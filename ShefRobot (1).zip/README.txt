#Windows Usage
1. Extract the contents of this zip directly into your working directory (the files should be in the same directory that you are calling `javac`).
2. Open a command prompt (cmd) window, and navigate to your working directory
3. Run `setupConsole.bat`
4. Compile/Run your java code as you would normally


#OS X/Linux Usage
1. Extract the contents of this zip directly into your working directory (the files should be in the same directory that you are calling `javac`).
2. Open a terminal window, and navigate to your working directory
3. Run `source setupConsole.sh`
4. Compile/Run your java code as you would normally
